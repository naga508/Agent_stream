import pandas as pd, numpy as np, re
from datetime import datetime
from dateutil import parser as dateparser

def _month_label(dt): return dt.strftime("%b %Y")
def _parse_month(text):
    try:
        dt = dateparser.parse(text, default=datetime(2025,1,1))
        return datetime(dt.year, dt.month, 1)
    except Exception: return None
def _extract_month(q):
    m = re.search(r'(jan(uary)?|feb(ruary)?|mar(ch)?|apr(il)?|may|jun(e)?|jul(y)?|aug(ust)?|sep(t)?(ember)?|oct(ober)?|nov(ember)?|dec(ember)?)\s*\d{4}', q, flags=re.I)
    if m: return _parse_month(m.group(0))
    m = re.search(r'\b(20\d{2})-(0[1-9]|1[0-2])\b', q)
    if m: return _parse_month(m.group(0)+'-01')
    return None
def _is_trend(q): return any(w in q.lower() for w in ["trend","trends","over time","by month","chart","plot","line","graph","show"])
def _vs_budget(q): return any(k in q.lower() for k in ["vs budget","versus budget","variance","budget"])

def _load(actuals_csv,budget_csv,fx_csv,cash_csv):
    a = pd.read_csv(actuals_csv, parse_dates=["date"])
    b = pd.read_csv(budget_csv, parse_dates=["date"])
    fx = pd.read_csv(fx_csv, parse_dates=["date"])
    cash = pd.read_csv(cash_csv, parse_dates=["date"])
    for df in (a,b):
        if "entity" not in df.columns: df["entity"]="Total"
        if "currency" not in df.columns: df["currency"]="USD"
    if "rate_to_usd" not in fx.columns: fx["rate_to_usd"]=1.0
    return a,b,fx,cash

def _to_usd(df, fx):
    m = pd.merge(df, fx, on=["date","currency"], how="left")
    m["rate_to_usd"] = m["rate_to_usd"].fillna(1.0)
    m["amount_usd"] = df["amount"] * m["rate_to_usd"]
    return m

def _build_pivots(a_usd,b_usd):
    def kind(acc):
        s=str(acc).lower()
        if s.startswith("opex"): return "Opex"
        if s.startswith("cogs"): return "Cogs"
        if s.startswith("revenue"): return "Revenue"
        return "Other"
    a_usd["Kind"]=a_usd["account"].map(kind)
    b_usd["Kind"]=b_usd["account"].map(kind)
    a=a_usd.pivot_table(index="date",columns="Kind",values="amount_usd",aggfunc="sum").fillna(0.0)
    b=b_usd.pivot_table(index="date",columns="Kind",values="amount_usd",aggfunc="sum").fillna(0.0)
    for col in ["Revenue","Cogs","Opex"]:
        if col not in a.columns: a[col]=0.0
        if col not in b.columns: b[col]=0.0
    def add(pv):
        pv=pv.copy().sort_index()
        pv["Gross Profit"]=pv["Revenue"]-pv["Cogs"]
        pv["Gross Margin %"]=np.where(pv["Revenue"]!=0,pv["Gross Profit"]/pv["Revenue"],np.nan)*100
        pv["EBITDA"]=pv["Revenue"]-pv["Cogs"]-pv["Opex"]
        pv["EBITDA %"]=np.where(pv["Revenue"]!=0,pv["EBITDA"]/pv["Revenue"],np.nan)*100
        return pv
    return add(a),add(b),a_usd

def _opex_breakdown(df_usd,month_dt):
    d=df_usd[(df_usd["date"]==month_dt)&(df_usd["account"].str.lower().str.startswith("opex"))].copy()
    d["category"]=d["account"].str.split(":",n=1).str[1].fillna("Other").str.strip()
    return d.groupby("category")["amount_usd"].sum().reset_index().sort_values("amount_usd",ascending=False)

def _cash_runway_months(cash_df,a_pv):
    recent=a_pv.iloc[-3:]
    net_burn=(recent["Opex"]+recent["Cogs"]-recent["Revenue"]).mean()
    latest_cash=cash_df.sort_values("date").iloc[-1]["cash_balance"]
    if net_burn<=0: return float("inf")
    return latest_cash/net_burn

def build_engine(actuals_csv,budget_csv,fx_csv,cash_csv):
    a,b,fx,cash=_load(actuals_csv,budget_csv,fx_csv,cash_csv)
    a_usd=_to_usd(a,fx); b_usd=_to_usd(b,fx)
    a_pv,b_pv,a_usd_enriched=_build_pivots(a_usd,b_usd)
    def answer(q:str,plotting=True):
        import matplotlib.pyplot as plt
        month_dt=_extract_month(q) or a_pv.index.max()
        trend=_is_trend(q); compare=_vs_budget(q)
        ql=q.lower()
        if "cash runway" in ql:
            m=_cash_runway_months(cash,a_pv)
            txt="Cash runway: ∞ months" if m==float("inf") else f"Cash runway: {m:.1f} months"
            return {"text":txt,"chart":None}
        if "gross margin" in ql:
            if trend:
                if plotting: plt.plot(a_pv.index,a_pv["Gross Margin %"]); plt.show()
                return {"text":"GM trend","chart":"rendered"}
            else:
                act=a_pv.loc[month_dt,"Gross Margin %"]; bud=b_pv.loc[month_dt,"Gross Margin %"]
                return {"text":f"GM — {_month_label(month_dt)} {act:.1f}% vs {bud:.1f}%","chart":None}
        if "opex" in ql:
            br=_opex_breakdown(a_usd_enriched,month_dt)
            return {"text":f"Opex total — {_month_label(month_dt)}: ${br['amount_usd'].sum():,.0f}","table":br}
        if "ebitda" in ql:
            act=a_pv.loc[month_dt,"EBITDA"]; bud=b_pv.loc[month_dt,"EBITDA"]
            return {"text":f"EBITDA — {_month_label(month_dt)} ${act:,.0f} vs {bud:,.0f}","chart":None}
        if trend:
            if plotting: plt.plot(a_pv.index,a_pv["Revenue"]); plt.show()
            return {"text":"Revenue trend","chart":"rendered"}
        else:
            act=a_pv.loc[month_dt,"Revenue"]; bud=b_pv.loc[month_dt,"Revenue"]
            return {"text":f"Revenue — {_month_label(month_dt)} ${act:,.0f} vs {bud:,.0f}","chart":None}
    return answer
